/**
 * 
 */
	//make the submit button have an onclick="validate()"
 function loginUser(){
			let url="http://localhost:8080/final/LoginServlet?user="
			+document.flogin.user.value+"&pass="+document.flogin.pass.value;
			
			fetch(url, {method:"POST"})
			.then(response=> response.json())
			.then((result) => {
				
				if (Number.isNaN(parseInt(result))){
					document.getElementById("wrong").innerHTML=result;
				} else {
					//result is the user id, how to store the user id.
					
					localStorage.setItem("userID", result);
					window.location.assign("NewFile1.html");
				}
				
			
			
			}).catch(function(error){
			
					console.log("request failed", error)
			});
		}
 
 